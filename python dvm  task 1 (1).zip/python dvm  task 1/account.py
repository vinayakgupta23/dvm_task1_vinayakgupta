import pickle as p
import math
def balance(self,key,list1):
    print("YOUR CURRENT ACCOUNT BALANCE IS RUPPEES  "+str(list1[key][2]))
def withdrawing(self,key,list1):
    r=int(input("PLEASE ENTER AMOUNT YOU WANT TO WITHDRAW"))
    if r > list1[key][2]:
        print("INSUFFICIENT BALANCE")
        print("----------------------------------------------------------------")
    else:
        list1[key][2]-=r
        print(str(r)+"  RUPPEES SUCCESSFULLY WITHDRAWN  CURRENT BALANCE LEFT "+ str(list1[key][2]))
    g=open("atmdata.dat",'wb')
    p.dump(list1,g)
    g.close()
    
def deposit(self,keyy,list1):
    r=int(input("PLEASE ENTER AMOUNT YOU WANT TO DEPOSIT  "))
    list1[keyy][2]+=r
    print(str(r)+"  RUPPEES SUCCESSFULLY DEPOSIT  CURRENT BALANCE LEFT "+str(list1[keyy][2]))
    g=open("atmdata.dat",'wb')
    p.dump(list1,g)
    g.close()

