import user
import account
import card 
import pickle as p
import random
import sys
class atm:
    def __init__(self):
        pass
file="atmdata.dat"
f=open(file,'rb')
list2=p.load(f)
f.close()
l=atm()
n=input("        INPUT YOUR NAME USER  ")
if user.check(l,n,list2)== None:
    while True:
        r=str(random.randint(100000000000,999999999999))
        if list2.get(r)==None:
            list2[r]=[n,int(input("input a new 4 digit pin  ")),0]
            print(list2)
            g=open(file,'wb')
            p.dump(list2,g)
            g.close()
            break
        else:
            continue
f=open(file,'rb')
list1=p.load(f)
print("PLEASE ENTER YOUR PIN TO GRANT ACCESS")
KEY=user.check(l,n,list1)
t=card.authen(l,KEY,list1)
if t==0:
    print("YOU ENTERED WRONG PIN 3 TIMES ")
    print("YOUR CARD IS BLOCKED ..............")
    sys.exit()
KEY=user.check(l,n,list1)
while True:
    print(" TYPE      B:VIEW BALANCE  D:DEPOSIT  W:WITHRAWL  C:PIN CHANGE  E:EXIT ")
    o=input()[0]
    if o=='B':
        q=account.balance(l,KEY,list1)
    elif o=='D':
        q=account.deposit(l,KEY,list1)
    elif o=='W':
        q=account.withdrawing(l,KEY,list1)
    elif o=='C':
        card.change(l,KEY,list1)
    elif o=='E':
        print("           THANK YOU FOR USING OUR BANK SERVICE   ")
        sys.exit()
    else:
        print("PLEASE ENTER CORRECT KEYWORD FOR FURTHER PROCCESS")
f.close()



