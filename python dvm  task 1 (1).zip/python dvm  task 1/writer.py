import pickle
import random
list ={'12345678900':["vinayak",1234,25000],
       '12345678901':["sharansh",2345,50000],
       '12345678902':["sarthak",3456,75000],
       '12345678905':["prasoon",4567,80000]}

file="atmdata.dat"
f=open(file,'wb')
pickle.dump(list,f)
f.close()
    
