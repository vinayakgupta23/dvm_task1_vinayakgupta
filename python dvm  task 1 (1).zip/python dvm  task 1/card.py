import pickle as p
import sys
def authen(self,key,list1):
    
    tries=3
    while tries:
        if int(input())== list1[key][1]:
            print("ACCESS GRANTED")
            return 1
        else:
            tries-=1
            print("WRONG PASSWORD  "+str(tries)+"  TRIES LEFT BEFORE CARD BLOCKING")
            continue
            
    return 0


def change(self,key,list2):
    print("PLEASE ENTER CURRENT PIN TO CHANGE YOUR PIN")
    if int(input())== list2[key][1]:
        print("ENTER NEW PIN")
        list2[key][1]=int(input())
        g=open("atmdata.dat",'wb')
        p.dump(list2,g)
        g.close()
        print("PIN UPDATED SUCCESSFULLY")
    else:
        print("YOU ENTERED WRONG PIN PROCESS TERMINATED..........")
        sys.exit()
        
